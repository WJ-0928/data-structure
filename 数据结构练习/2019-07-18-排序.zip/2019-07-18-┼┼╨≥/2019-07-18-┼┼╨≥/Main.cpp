#include "Sort.h"

int main() {
	test();
}