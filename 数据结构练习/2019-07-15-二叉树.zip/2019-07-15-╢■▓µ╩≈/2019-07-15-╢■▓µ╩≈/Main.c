#include "BinaryTree.h"

int main() {
	test();
}