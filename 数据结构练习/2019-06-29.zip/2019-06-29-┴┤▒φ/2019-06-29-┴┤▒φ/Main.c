#include "LinkedList.h"

int main() {
	Test();
}